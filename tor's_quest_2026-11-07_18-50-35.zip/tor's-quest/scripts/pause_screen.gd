extends CanvasLayer


var game_started = false
var paused = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	game_started = false
	paused = false
	hide()

func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("pause") and game_started:
		toggle()

func _on_title_screen_start_game() -> void:
	game_started = true

func toggle():
	if game_started:
		paused = not paused
		get_tree().paused = paused
		visible = paused

func _on_restart_button_pressed() -> void:
	toggle()
	get_tree().reload_current_scene()

func _on_exit_button_pressed() -> void:
	get_tree().quit()
