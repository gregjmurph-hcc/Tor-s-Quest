extends CanvasLayer


signal start_game

func _ready() -> void:
	show()

func _on_play_button_pressed() -> void:
	start_game.emit()
	hide()

func _on_exit_button_pressed() -> void:
	get_tree().quit()
