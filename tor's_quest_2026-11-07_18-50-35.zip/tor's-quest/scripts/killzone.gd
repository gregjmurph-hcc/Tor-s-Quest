extends Area2D


@onready var player = $"../../Player"
@onready var player_start_position = $"../PlayerStartPosition"
@onready var timer = $Timer

func _on_body_entered(body: Node2D) -> void:
	player.take_damage(1)
	player.paused = true
	timer.start()

func _on_timer_timeout() -> void:
	if player.lives < 0:
		return

	player.position = player_start_position.position
	player.paused = false
