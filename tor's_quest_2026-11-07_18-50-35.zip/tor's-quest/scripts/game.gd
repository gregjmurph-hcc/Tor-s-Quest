extends Node


@onready var stage_1_scene = $Stage1
@onready var player = $Player
@onready var hud = $Hud

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	stage_1_scene.hide()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_title_screen_start_game() -> void:
	stage_1_scene.show()
	player.show()
	hud.show()
