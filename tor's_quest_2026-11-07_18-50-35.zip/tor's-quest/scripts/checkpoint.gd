extends Area2D


@onready var player_start_position = $"../../PlayerStartPosition"

var activate = false

func _on_body_entered(body: Node2D) -> void:
	if activate:
		return
		
	player_start_position.position = get_global_transform().get_origin()
	print(player_start_position.position)
	activate = true
