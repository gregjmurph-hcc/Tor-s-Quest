extends CharacterBody2D


signal health_changed(lives: int, health: int)
signal out_of_lives

@onready var sprite = $AnimatedSprite2D
@export var max_health = 3
@export var starting_lives = 3 

const GRAVITY = 2000
const MOVE_SPEED = 200
const SPRINT_SPEED = 300
const JUMP_SPEED = -600
const JUMP_CUT_MULTIPLIER = 0.5
const JUMP_BUFFER_TIME = 0.10
const WALL_JUMP_CONTROL_LOCK = 0.18
const WALL_JUMP_SPEED_X = 400
const WALL_JUMP_SPEED_Y = -400
const WALL_SLIDE_SPEED = 100
const ACCEL = 2000
const DECEL = 3000
const COYOTE_TIME = 0.05

var jump_buffer_timer = 0.0
var wall_jump_lock_timer = 0.0
var coyote_timer = 0.0
var lives: int
var health: int
var is_dead = false
var facing = false
var paused = false

func _ready() -> void:
	hide()
	lives = starting_lives
	health = max_health
	health_changed.emit(lives, health)

func _physics_process(delta: float) -> void:
	if paused:
		return
	
	var direction = Input.get_axis("left", "right")
	
	if Input.is_action_just_pressed("jump"):
		jump_buffer_timer = JUMP_BUFFER_TIME
	else:
		jump_buffer_timer = maxf(jump_buffer_timer - delta, 0.0)
	
	wall_jump_lock_timer = maxf(wall_jump_lock_timer - delta, 0.0)
	
	if is_on_floor():
		sprite.animation = "idle"
		coyote_timer = COYOTE_TIME
	else:
		coyote_timer = maxf(coyote_timer - delta, 0.0)
		velocity.y += GRAVITY * delta
		sprite.animation = "falling"
	
	var clinging = is_on_wall() and not is_on_floor()
	var wall_normal = get_wall_normal() if clinging else Vector2.ZERO
	
	if clinging:
		facing = wall_normal.x < 0.0
		velocity.x = 0.0
		if velocity.y > WALL_SLIDE_SPEED:
			velocity.y = WALL_SLIDE_SPEED
			
	if jump_buffer_timer > 0.0 and clinging:
		velocity.x = wall_normal.x * WALL_JUMP_SPEED_X
		velocity.y = WALL_JUMP_SPEED_Y
		wall_jump_lock_timer = WALL_JUMP_CONTROL_LOCK
		jump_buffer_timer = 0.0
	elif jump_buffer_timer > 0.0 and (is_on_floor() or coyote_timer > 0.0):
		sprite.animation = "jump"
		velocity.y = JUMP_SPEED
		jump_buffer_timer = 0.0
	
	if not clinging and wall_jump_lock_timer <= 0.0:
		if direction != 0.0:
			velocity.x += direction * ACCEL * delta
			if Input.is_action_pressed("sprint"):
				velocity.x = clampf(velocity.x, -SPRINT_SPEED, SPRINT_SPEED)
			else:
				velocity.x = clampf(velocity.x, -MOVE_SPEED, MOVE_SPEED)
			
			if velocity.y == 0:
				sprite.animation = "walk" 
		else:
			velocity.x = move_toward(velocity.x, 0, DECEL * delta)
	
	if not clinging and direction != 0.0 and wall_jump_lock_timer <= 0.0:
		facing = direction < 0.0
	
	sprite.flip_h = facing
	
	if Input.is_action_just_released("jump") and velocity.y < 0:
		velocity.y *= JUMP_CUT_MULTIPLIER
		
	move_and_slide()

func take_damage(amount: int):
	if is_dead:
		return
		
	health = max(health - amount, 0)
	health_changed.emit(lives, health)
	
	if health == 0:
		lose_life()
		
func lose_life():
	is_dead = true
	lives -= 1
	health_changed.emit(lives, health)
	
	if lives < 0:
		out_of_lives.emit()
	else:
		health = max_health
		is_dead = false
		health_changed.emit(lives, health)
