extends HBoxContainer


@onready var player = $"../../Player"
@export var full_heart: Texture2D
@export var empty_heart: Texture2D
@export var max_health = 3

var current_health = 3

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	update_hearts()

func set_health(new_health: int):
	current_health = clamp(new_health, 0, max_health)
	update_hearts()
	
func update_hearts():
	for child in get_children():
		child.queue_free()
		
	for i in range(max_health):
		var heart = TextureRect.new()
		heart.texture = full_heart if i < current_health else empty_heart
		heart.custom_minimum_size = Vector2(16, 16)
		heart.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		heart.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		add_child(heart)

func _on_player_health_changed(_lives: int, health: int) -> void:
	set_health(health)
