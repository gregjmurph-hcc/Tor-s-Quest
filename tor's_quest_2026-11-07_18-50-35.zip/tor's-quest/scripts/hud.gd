extends CanvasLayer


@onready var player = $"../Player"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	update_lives_label(player.lives)
	hide()
	
func update_lives_label(lives: int):
	if lives < 0:
		return
		
	$PlayerLivesLabel.text = "Lives x " + str(lives)

func _on_player_health_changed(lives: int, _health: int) -> void:
	update_lives_label(lives)
